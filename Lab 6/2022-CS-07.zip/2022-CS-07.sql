--Q1
USE northwind
SELECT CustomerID,
(SELECT TOP (1)Orders.OrderID FROM Orders WHERE Orders.CustomerID = Customers.CustomerID ORDER BY OrderDate DESC),
(SELECT TOP (1) Orders.OrderDate FROM Orders WHERE Orders.CustomerID = Customers.CustomerID ORDER BY OrderDate DESC)
FROM Customers
